// Copyright 2026 Yandex LLC. All rights reserved.
const status = document.getElementById('status');

function download(index) {
  const filename = `abro-26903-${Date.now()}-${index}.txt`;
  status.textContent += `\nRequested: ${filename}`;
  chrome.downloads.download({
    url: 'data:text/plain;charset=utf-8,' +
        encodeURIComponent('ABRO-26903 extension download confirmation test\n'),
    filename,
    saveAs: false,
  }, id => {
    const error = chrome.runtime.lastError;
    status.textContent += error
        ? `\nCanceled/error: ${error.message}`
        : `\nStarted: ${id}`;
  });
}

document.getElementById('one').addEventListener('click', () => download(1));
document.getElementById('two').addEventListener('click', () => {
  download(1);
  download(2);
});
